## section 1

z <- 123

## section 2

weight_kg <- 10

w2 <- weight_kg * 2

## Function

round(3.14142628282763)

round(3.14142628282763, digits = 2)

round(digits = 2, x = 3.14142628282763)

round(3.14142628282763, digits = 2)

seq(from = 1, to = 10, by = 3)
seq(1, 10, 3)

seq(1, 10, length.out = 5)

## vector

weight_g <- c(50, 60, 65, 82)

animals <- c("mouse", "rat", "dog")
animals
length(animals)

x <- "1"
length(x)
x

class(weight_g)
class(animals)

weight_g <- weight_g + 1


c(10, weight_g)

c(weight_g, 100)

num_char <- c(1, 2, 3, "a")

num_logical <- c(1, 2, 3, TRUE)

char_logical <- c("a", "b", "c", TRUE)

tricky <- c(1, 2, 3, "4")

## subsetting

c(10, weight_g)


weight_g[1]
weight_g[2]

weight_g[c(1, 2)]

## 51, 61, 10, 66, 83

weight_g[c(1, 2)]

c(weight_g[1:2],  10, weight_g[3:4])

w2 <- c(  weight_g[c(1, 2)],   10  , weight_g[c(3, 4)]   )

w2[c(1, 3)]
w2[c(TRUE, FALSE, TRUE, FALSE, FALSE)]

w2[w2 < 60]

w2[w2 < 32]

w2 < 60

w2 > 80

w2[w2 < 60 | w2 > 80]
w2[w2 < 60 & w2 > 80]

animals <- c("mouse", "rat", "dog")
animals
animals == "dog" | animals == "rat"

!TRUE
!FALSE

animals != "dog" 

!(animals == "dog")


## missing data

heights <- c(2, 4, 4, NA, 6)
heights
class(heights)
length(heights)

mean(heights)
?mean
mean(heights, na.rm = TRUE)

heights[!is.na(heights)]

mean(heights[!is.na(heights)])

mean(heights[!is.na(heights)])

na.omit(weight_g)

complete.cases(heights)











