## RNASeq data and annotation

# 1. Import the data from two tab-separated files into R. 
#    The kem_counts.tsv file contains RNA-Seq expression 
#    counts for 13 genes and 18 samples and kem_annot.tsv 
#    contains annotation about each sample. Read the data into 
#    two tibbles named `kem` and `annot` respectively 
#    and familiarise yourself with the content of the two new tables.

library(tidyverse)
annot <- read_tsv("data/kem_annot.tsv")
kem <- read_tsv("data/kem_counts.tsv")
View(kem)
View(annot)

# 2. Convert the counts data into a long table 
#   format and annotation each sample using the 
#   experimental design.

k2 <- gather(kem,   
       key = sample_id, 
       value = counts,
       -ref)

k3 <- full_join(k2, annot)
View(k3)

    
# 3. Identity the three transcript identifiers 
#    that have the highest expression count over 
#    all samples.

ksel <- k3 %>% 
  group_by(ref) %>% 
  summarise(tot_couts = sum(counts)) %>% 
  arrange(desc(tot_couts)) %>% 
  head(3)

kmax <- k3 %>% 
  filter(k3$ref %in% ksel$ref)

# 4. Visualise the distribution of the expression 
#    for the three transcripts selected above in cell 
#   types A and B under both treatments.

ggplot(kmax, 
       aes(x = treatment, 
           y = counts)) +
  geom_boxplot() +
  geom_jitter() +
  facet_grid(ref ~ cell_type)


# 5. For all genes, calculate the mean intensities in 
#    each experimental group (as defined by the `cell_type` 
#    and `treatment` variables).
#    
# 6. Focusing only on the three most expressed transcripts 
#    and cell type A, calculate the fold-change induced by 
#    the treatment. The fold-change is the ratio between the 
#    average expressions in two conditions.
   




## Quantitative proteomics statistical results

# 1. Download and load the `prot.csv` file into R.
# 
# 2. Produce a histogram of p-value. Discuss the distribution 
#    of these p-values.
# 
# 3. Produce a volcano plot, showing the log2 fold-change along the x
#    axis and -log10 of the adjusted p-value along the y axis. Discuss.
# 
# 4. Produce an MA plot, showing the average intensity (over all
#    samples) along the x axis, and the log2 fold-change along the y
#    axis. Discuss.

