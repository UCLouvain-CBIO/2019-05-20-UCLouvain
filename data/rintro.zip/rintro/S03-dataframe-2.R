download.file(url="https://ndownloader.figshare.com/files/2292169", 
              destfile = "data/portal_data_joined.csv")


surveys <- read.csv("data/portal_data_joined.csv")


surveys[1:4, 2:5]

surveys[1:4, -1]

## Challenge
##
## 1. Create a data.frame (surveys_200) containing only the data in row
##    200 of the surveys dataset.

(surveys_200 <- surveys[200, ])

## 2. Notice how nrow() gave you the number of rows in a data.frame?
##    - Use that number to pull out just that last row in the data 
##    - Pull out that last row using nrow() instead of the row number.

n_row <- nrow(surveys)
surveys[34786, ]
surveys[n_row, ]

## 3. Use nrow() to extract the row that is in the middle of the data
##    frame. Store the content of this row in an object named
##    surveys_middle.

(surveys_middle <- surveys[n_row/2, ])

## 4. Combine nrow() with the - notation above to reproduce the behavior
##    of head(surveys), keeping just the first through 6th rows of the
##    surveys dataset.

head(surveys)
surveys[1:6, ]

surveys[-(7:n_row), ]

-(1:10)
  














