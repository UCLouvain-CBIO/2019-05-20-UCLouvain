install.packages("tidyverse")

library(tidyverse)

surveys <- read_csv("data/portal_data_joined.csv")
surveys

select(surveys, plot_id, species_id, weight)

select(surveys, -record_id, -species_id)

filter(surveys, year == 1995)

tmp <- filter(surveys, weight < 5)
select(tmp, species_id, sex, weight)

select(filter(surveys, weight < 5), 
       species_id, sex, weight)

surveys %>% 
  filter(weight  < 5) %>% 
  select(species_id, sex, weight)

## Using pipes, subset the surveys data to include 
## animals collected before 1995 and retain only 
## the columns year, sex, and weight.

surveys %>% 
  filter(year < 1995) %>% 
  select(year, sex, weight)

surveys %>% 
  mutate(w_kg = weight/1000)

surveys %>% 
  mutate(w_kg = weight/1000,
         w2 = weight * 2)

s2 <- surveys %>% 
  mutate(w_kg = weight/1000) %>% 
  mutate(w2 = weight * 2)


surveys %>% 
  filter(!is.na(weight)) %>% 
  mutate(w_kg = weight/1000,
         w2 = weight * 2) %>% 
  select(weight, w2, w_kg)


## Create a new data frame from the surveys data 
## that meets the following criteria: contains 
## only the species_id column and a new column 
## called hindfoot_half containing values that are 
## half the hindfoot_length values. In this 
## hindfoot_half column, there are no NAs and all 
## values are less than 30.

surveys %>% 
  filter(!is.na(hindfoot_length)) %>% 
  mutate(hindfoot_half = hindfoot_length/2) %>% 
  filter(hindfoot_half < 30) %>% 
  select(species_id, hindfoot_half)


surveys %>% 
  mutate(hindfoot_half = hindfoot_length/2) %>% 
  filter(hindfoot_half < 30,
         !is.na(hindfoot_length)) %>% 
  select(species_id, hindfoot_half)


surveys %>% 
  group_by(sex) %>% 
  summarise(mean_weight = mean(weight, na.rm = TRUE))


unique(surveys$species_id)

unique(surveys[ , "species_id"])

surveys %>% 
  group_by(sex, species_id) %>% 
  summarise(mean_weight = mean(weight, na.rm = TRUE)) 

surveys %>%
  filter(!is.na(weight)) %>%
  group_by(sex, species_id) %>%
  summarize(mean_weight = mean(weight),
            min_weight = min(weight)) %>% 
  arrange(min_weight)

surveys %>%
  filter(!is.na(weight)) %>%
  group_by(sex, species_id) %>%
  summarize(mean_weight = mean(weight),
            min_weight = min(weight)) %>% 
  arrange(desc(min_weight))


surveys %>% 
  count(sex)

surveys %>% 
  count(sex, species_id)


## How many animals were caught 
## in each plot_type surveyed?

surveys %>% 
  count(plot_type)
  
## Use group_by() and summarize() to find the mean, 
## min, and max hindfoot length  for each species 
## (using species_id). 
## Also add the number of observations (hint: see ?n).

surveys %>% 
  filter(!is.na(hindfoot_length)) %>% 
  group_by(species_id) %>% 
  summarise(mean_hl = mean(hindfoot_length),
            min_hl = min(hindfoot_length),
            max_hl = max(hindfoot_length),
            n = n())

## What was the heaviest animal measured in each year?
## Return the columns year, genus, species_id, 
## and weight.

surveys %>% 
  filter(!is.na(weight)) %>% 
  group_by(year) %>% 
  filter(weight == max(weight)) %>% 
  select(year, species_id, weight) %>%
  arrange(year) 


## Let’s start by removing observations of animals for which 
## weight and hindfoot_length are missing, or the sex has not 
## been determined. Create a new dataset called surveys_complete.

surverys_complete <- surveys %>% 
  filter(!is.na(weight), 
         !is.na(hindfoot_length),
         !is.na(sex))
  
## Count how many individuals of each species were surveyed?

species_count <- surverys_complete %>% 
  count(species_id) %>% 
  filter(n >= 50)

## In surveys_complete, keep only the species that were observed 
## more than 50 times.

surveys_complete <- surverys_complete %>% 
  filter(species_id %in% species_count$species_id)

write_csv(surveys_complete, path = "data/surveys_complete.csv")

c("a", "A") %in% letters

c("a", "A") %in% LETTERS















