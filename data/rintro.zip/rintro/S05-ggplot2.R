library(tidyverse)

ggplot(data = surveys_complete,
       mapping = aes(x = weight, 
                     y = hindfoot_length)) +
    geom_point()


surveys_complete %>% 
    filter(hindfoot_length == max(hindfoot_length) |
           hindfoot_length == min(hindfoot_length)) %>% 
    select(genus, species, hindfoot_length)

ggplot(surveys_complete, 
       aes(x = weight,
           y = hindfoot_length)) +
    geom_point(aes(colour = species_id)) +
    geom_line()
  
ggplot(surveys_complete, 
       aes(x = weight,
           y = hindfoot_length)) +
    geom_line() + 
    geom_point(aes(colour = species_id))

## scatterplot of WEIGHT (y) over SPECIES_ID (x) and 
## color by PLOT_ID

surveys_complete %>% 
    ggplot(aes(species_id, weight)) +
    geom_point(aes(color = factor(plot_id)))


surveys_complete %>% 
    ggplot(aes(species_id, weight)) +
    geom_boxplot() +
    geom_jitter(alpha = 0.2)

surveys_complete %>% 
    ggplot(aes(species_id, weight)) +
    geom_jitter(alpha = 0.2,
                size = .1,
                aes(color = species_id)) +
    geom_boxplot(alpha = 0.2)
    

surveys_complete %>% 
    ggplot(aes(species_id, weight)) +
    geom_violin()

surveys_complete %>% 
    mutate(hindfoot_log = log10(hindfoot_length)) %>% 
    ggplot(aes(species_id, hindfoot_log)) +
    geom_violin()

surveys_complete %>% 
    ggplot(aes(x = species_id, y = log10(hindfoot_length))) +
    geom_violin()

surveys_complete %>% 
    ggplot(aes(species_id, hindfoot_length)) +
    geom_violin() +
    scale_y_log10()



yearly_count <- surveys_complete %>% 
    count(year, species_id)


ggplot(yearly_count, 
       aes(x = year,
           y = n,
           color = species_id)) +
    geom_line() +
    geom_point(color = "black")

ggplot(yearly_count, 
       aes(x = year,
           y = n)) +
    geom_line(aes(color = species_id))



ggplot(yearly_count, 
       aes(x = year,
           y = n)) +
    geom_line() +
    facet_wrap( ~ species_id)

surveys_complete %>% 
    count(year, species_id, sex) %>% 
    filter(!is.na(sex)) %>% 
    ggplot(aes(x = year, y = n, linetype = sex)) +
    geom_line() +
    facet_wrap(~species_id) +
    labs(title = "Observed species over time",
         x = "Year of observetion",
         y = "Number of individuals") +
    theme(plot.title = element_text(hjust = .5),
          legend.position = "bottom")

ggsave("Fig1.pdf", width = 297, height = 210, units = "mm", dpi = 300)










































    







