download.file(url="https://ndownloader.figshare.com/files/2292169", 
              destfile = "data/portal_data_joined.csv")


surveys <- read.csv("data/portal_data_joined.csv")
class(surveys)

View(surveys)

head(surveys)
tail(surveys)

str(surveys)
?read.csv

dim(surveys)
nrow(surveys)
ncol(surveys)

names(surveys)


head(surveys[ , 1:2 ])

surveys[1:2, ]

surveys[4, ]

surveys[1:4, c(1, 5)]

surveys[4, "plot_id"]

surveys[4, 5]


